#!/bin/sh	
sed -i "s/flag{test}/$FLAG/" /var/www/html/sejishikong.php 
export FLAG=""	
