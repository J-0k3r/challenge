<?php
$flag="flag{test}";
echo "冲完啦？拿上你的flag赶紧走".$flag;
?>