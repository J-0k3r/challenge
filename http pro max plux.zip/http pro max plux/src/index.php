<?php
$flag = "flag{testflag}";
error_reporting(0);
function getClientIP(){       
     if (array_key_exists('HTTP_X_FORWARDED_FOR', $_SERVER)){
            return  $_SERVER["HTTP_X_FORWARDED_FOR"];  
     }else if (array_key_exists('REMOTE_ADDR', $_SERVER)) { 
            return $_SERVER["REMOTE_ADDR"]; 
     }else if (array_key_exists('HTTP_CLIENT_IP', $_SERVER)) {
            return $_SERVER["HTTP_CLIENT_IP"]; 
     }else if  (array_key_exists('HTTP_USER_AGENT', $_SERVER)) {
       return $_SERVER['HTTP_USER_AGENT'];
     }else if  (array_key_exists('HTTP_VIA', $_SERVER)) {
       return $_SERVER['HTTP_VIA'];
     }
     return '';
}

if($_SERVER['HTTP_X_FORWARDED_FOR']== '127.0.0.1'){
    die('<h1>只会xff？真是逊呐</h1>');
}

if($_SERVER['HTTP_CLIENT_IP']!= '127.0.0.1'){
    die('<h1>只允许本地访问</h1>');
}
if($_SERVER['HTTP_REFERER'] != 'pornhub.com'){
    die('<h1>You are not from pornhub.com !</h1>');
}
if ($_SERVER['HTTP_USER_AGENT'] != 'Chrome'){
       die('<h1>用Chrome浏览器啊!</h1>');
 }
if ($_SERVER['HTTP_VIA'] != 'Clash.win'){
       die('<h1>不开代理你想上p站？</h1><h9>代理服务器地址是Clash.win</h9>');
 }
echo '借一步说话--->>  /wtfwtfwtfwtf.php';
?>
